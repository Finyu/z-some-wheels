<template>
  <div>
    <header>
      <a class='homeLink'>
        Z-some-wheels
      </a>
      <div class='linkAndSeach'>
        链接
      </div>
    </header>
    <article>
      <div  class='leftContent'>
        <el-scrollbar style='height:100%;'>
          <navz :routerData='routerData'></navz>
        </el-scrollbar>
      </div>
      <div class='rightContent'>
        <div class='showMainBody'>
          <router-view></router-view>
        </div>
      </div>
    </article>
  </div>
</template>

<script>
import navz from '@/components/navz/navz.js'
import nav from '../router.json'
export default {
  data(){
    return  {
      routerData: nav
    }
  },
  components: {
    navz
  }
}
</script>

<style lang='stylus'>
header
  display flex
  color #2c3e50
  font-weight 600
  justify-content space-between
  height 60px
  padding  0 20px
  line-height 60px
  border-bottom 1px #eaecef solid
  background-color white
  .homeLink
    font black
    font-size 20px
    line-height 60px
    height 100%
    display block
    cursor pointer
  .linkAndSeach
    font #888888 
    font-size 12px
    line-height 60px
    height 100%
    display block
    cursor pointer
article
  height calc(100vh - 60px)
  display flex
  .leftContent
    width 320px
    height 100%
    background-color white
    border-right  1px solid #eaecef
    .el-scrollbar__wrap
      overflow-x hidden
      .Z-leftTree
        padding 20px 0 20px 20px
        .Z-nav-title
          font-size 18px
          font-weight 600
          color #999
          margin 20px 0
        .Z-nav-common
          font-size 14px
          color black
          margin 15px 0px 15px 5px
          cursor pointer
  .rightContent
    width calc(100vw - 320px)
    transition  all .5s
    .showMainBody
      width 800px
      margin 0 auto
</style>